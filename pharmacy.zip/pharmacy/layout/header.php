<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><? echo $title ?></title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.css"/>
    <link rel="stylesheet" href="/pharmacy/assets/css/main.css">
</head>
<body>
    <header class="grid-container py-4 relative">
        <div class="flex items-center justify-between gap-8">
            <a href="/pharmacy" class="flex items-center gap-2 text-[#00897B]">
                <img src="/pharmacy/assets/images/header/logo.svg" alt="" class="w-8">
                <p class="font-Nunito tracking-widest">Фармия</p>
            </a>
            <div id="menu" class="flex items-center gap-4 max-lg:flex-col max-lg:w-full max-lg:absolute max-lg:top-0 max-lg:left-0 max-lg:-translate-y-full max-lg:py-6 max-lg:px-4 max-lg:bg-white max-lg:border-t border-[#00897B] max-lg:z-[5] transition-all duration-500">
                <a href="/pharmacy/pages/catalog.php" class="rounded-xl bg-[#00897B] text-white px-4 py-1.5 border border-[#00897B] transition-all duration-500 hover:text-[#00897B] hover:bg-white">Каталог</a>
                <form action="/pharmacy/pages/catalog.php" method="GET" class="relative">
                    <input type="text" name="search" class="rounded-full w-full md:w-[500px] pl-4 pr-12 py-1.5 border border-[#00897B] focus:outline-none">
                    <button type="submit" class="absolute top-1/2 -translate-y-1/2 right-2">
                        <img src="/pharmacy/assets/images/header/search.svg" alt="" class="w-8">
                    </button>    
                </form>
                <?if(isset($_SESSION['user']) && $_SESSION['user']['role'] == '2') {?>
                <?} else {?>
                    <a href="/pharmacy/pages/cart.php" class="flex flex-col items-center text-center gap-0.5 group">
                        <svg class="w-6 transition-all duration-500 stroke-[#374151] group-hover:stroke-[#00897B]" viewBox="0 0 24 24" fill="none"
                            xmlns="http://www.w3.org/2000/svg">                    
                            <g id="SVGRepo_bgCarrier" stroke-width="0" />                    
                            <g id="SVGRepo_tracerCarrier" stroke-linecap="round" stroke-linejoin="round"/>                    
                            <g id="SVGRepo_iconCarrier">
                                <path
                                    d="M7.5 18C8.32843 18 9 18.6716 9 19.5C9 20.3284 8.32843 21 7.5 21C6.67157 21 6 20.3284 6 19.5C6 18.6716 6.67157 18 7.5 18Z"
                                    stroke-width="1.5" />
                                <path
                                    d="M16.5 18.0001C17.3284 18.0001 18 18.6716 18 19.5001C18 20.3285 17.3284 21.0001 16.5 21.0001C15.6716 21.0001 15 20.3285 15 19.5001C15 18.6716 15.6716 18.0001 16.5 18.0001Z"
                                    stroke-width="1.5" />
                                <path
                                    d="M2 3L2.26121 3.09184C3.5628 3.54945 4.2136 3.77826 4.58584 4.32298C4.95808 4.86771 4.95808 5.59126 4.95808 7.03836V9.76C4.95808 12.7016 5.02132 13.6723 5.88772 14.5862C6.75412 15.5 8.14857 15.5 10.9375 15.5H12M16.2404 15.5C17.8014 15.5 18.5819 15.5 19.1336 15.0504C19.6853 14.6008 19.8429 13.8364 20.158 12.3075L20.6578 9.88275C21.0049 8.14369 21.1784 7.27417 20.7345 6.69708C20.2906 6.12 18.7738 6.12 17.0888 6.12H11.0235M4.95808 6.12H7"
                                    stroke-width="1.5" stroke-linecap="round" />
                            </g>
                        
                        </svg>
                        <span class="text-base text-gray-700 transition-all duration-500 group-hover:text-[#00897B]">Корзина</span>
                    </a>
                <?}?>                <?if(!isset($_SESSION['user'])) { ?>
                    <a href="/pharmacy/pages/auth.php" class="flex flex-col items-center text-center gap-0.5 group">
                        <svg class="w-6 transition-all duration-500 stroke-[#374151] group-hover:stroke-[#00897B]" viewBox="0 0 24 24"
                            fill="none" xmlns="http://www.w3.org/2000/svg">                        
                            <g id="SVGRepo_bgCarrier" stroke-width="0" />                        
                            <g id="SVGRepo_tracerCarrier" stroke-linecap="round" stroke-linejoin="round" />                        
                            <g id="SVGRepo_iconCarrier">
                                <path
                                    d="M12.1601 10.87C12.0601 10.86 11.9401 10.86 11.8301 10.87C9.45006 10.79 7.56006 8.84 7.56006 6.44C7.56006 3.99 9.54006 2 12.0001 2C14.4501 2 16.4401 3.99 16.4401 6.44C16.4301 8.84 14.5401 10.79 12.1601 10.87Z"
                                    stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
                                <path
                                    d="M7.15997 14.56C4.73997 16.18 4.73997 18.82 7.15997 20.43C9.90997 22.27 14.42 22.27 17.17 20.43C19.59 18.81 19.59 16.17 17.17 14.56C14.43 12.73 9.91997 12.73 7.15997 14.56Z"
                                    stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
                            </g>                        
                        </svg>
                        <span class="text-base text-gray-700 transition-all duration-500 group-hover:text-[#00897B]">Войти</span>
                    </a>
                <? } elseif($_SESSION['user']['role'] == '2') {?>
                    <a href="/pharmacy/pages/admin.php" class="flex flex-col items-center text-center gap-0.5 group">
                        <svg class="w-6 transition-all duration-500 fill-[#374151] group-hover:fill-[#00897B]" viewBox="0 0 1920 1920" xmlns="http://www.w3.org/2000/svg">
                            <path d="M276.941 440.584v565.722c0 422.4 374.174 625.468 674.71 788.668l8.02 4.292 8.131-4.292c300.537-163.2 674.71-366.268 674.71-788.668V440.584l-682.84-321.657L276.94 440.584Zm682.73 1479.529c-9.262 0-18.523-2.372-26.993-6.89l-34.9-18.974C588.095 1726.08 164 1495.906 164 1006.306V404.78c0-21.91 12.65-41.788 32.414-51.162L935.727 5.42c15.134-7.228 32.866-7.228 48 0l739.313 348.2c19.765 9.374 32.414 29.252 32.414 51.162v601.525c0 489.6-424.207 719.774-733.779 887.943l-34.899 18.975c-8.47 4.517-17.731 6.889-27.105 6.889Zm467.158-547.652h-313.412l-91.595-91.482v-83.803H905.041v-116.78h-83.69l-58.503-58.504c-1.92.113-3.84.113-5.76.113-176.075 0-319.285-143.21-319.285-319.285 0-176.075 143.21-319.398 319.285-319.398 176.075 0 319.285 143.323 319.285 319.398 0 1.92 0 3.84-.113 5.647l350.57 350.682v313.412Zm-266.654-112.941h153.713v-153.713L958.462 750.155l3.953-37.27c1.017-123.897-91.595-216.621-205.327-216.621S550.744 588.988 550.744 702.72c0 113.845 92.612 206.344 206.344 206.344l47.21-5.309 63.811 63.7h149.873v116.78h116.781v149.986l25.412 25.299Zm-313.4-553.57c0 46.758-37.949 84.706-84.706 84.706-46.758 0-84.706-37.948-84.706-84.706s37.948-84.706 84.706-84.706c46.757 0 84.706 37.948 84.706 84.706"/>
                        </svg>
                        <span class="text-base text-gray-700 transition-all duration-500 group-hover:text-[#00897B]">Админ панель</span>
                    </a>
                <?} else {?>
                    <a href="/pharmacy/pages/profile.php" class="flex flex-col items-center text-center gap-0.5 group">
                        <svg class="w-6 transition-all duration-500 stroke-[#374151] group-hover:stroke-[#00897B]" viewBox="0 0 24 24"
                            fill="none" xmlns="http://www.w3.org/2000/svg">                        
                            <g id="SVGRepo_bgCarrier" stroke-width="0" />                        
                            <g id="SVGRepo_tracerCarrier" stroke-linecap="round" stroke-linejoin="round" />                        
                            <g id="SVGRepo_iconCarrier">
                                <path
                                    d="M12.1601 10.87C12.0601 10.86 11.9401 10.86 11.8301 10.87C9.45006 10.79 7.56006 8.84 7.56006 6.44C7.56006 3.99 9.54006 2 12.0001 2C14.4501 2 16.4401 3.99 16.4401 6.44C16.4301 8.84 14.5401 10.79 12.1601 10.87Z"
                                    stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
                                <path
                                    d="M7.15997 14.56C4.73997 16.18 4.73997 18.82 7.15997 20.43C9.90997 22.27 14.42 22.27 17.17 20.43C19.59 18.81 19.59 16.17 17.17 14.56C14.43 12.73 9.91997 12.73 7.15997 14.56Z"
                                    stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
                            </g>                        
                        </svg>
                        <span class="text-base text-gray-700 transition-all duration-500 group-hover:text-[#00897B]">Профиль</span>
                    </a>
                <?}?>                
            </div>
            <button id="toggler" class="lg:hidden">
                <img src="/pharmacy/assets/images/header/menu.svg" alt="" class="w-8">
            </button>
        </div>
    </header>

    <div id="overlay" class="absolute inset-0 z-[4] bg-black/30 top-16 max-lg:hidden hidden"></div>

    <main class="grid-container my-10 gap-y-12 grow">