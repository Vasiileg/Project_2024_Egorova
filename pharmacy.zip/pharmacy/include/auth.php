<?php 
session_start();
include 'db.php';

$login = mysqli_real_escape_string($db, $_POST['login']);
$psw = mysqli_real_escape_string($db, $_POST['password']);

$checkLogin = mysqli_query($db, "SELECT * FROM `users` WHERE `login` = '$login'");

if(mysqli_num_rows($checkLogin) > 0) {
    $user = mysqli_fetch_assoc($checkLogin);
    if(password_verify($psw, $user['password'])) {
        $_SESSION['user'] = [
            'id' => $user['id'],
            'role' => $user['role']
        ];
        $_SESSION['message'] = 'Вы успешно авторизовались!';
        header('Location: ../index.php');
    } else {
        $_SESSION['error'] = 'Пароли не совпадают!';
        header('Location: ' . $_SERVER['HTTP_REFERER']);
    }
} else { 
    $_SESSION['error'] = 'Пользователь с таким логином не существует!';
    header('Location: ' . $_SERVER['HTTP_REFERER']);
}
?>