<?php 
session_start();
include 'db.php';

$id = $_GET['id'];
$userId = $_SESSION['user']['id'];

mysqli_query($db, "DELETE FROM `cart` WHERE `id` = '$id'");

$_SESSION['message'] = 'Заказ удален!';
header('Location: ' . $_SERVER['HTTP_REFERER']);
?>