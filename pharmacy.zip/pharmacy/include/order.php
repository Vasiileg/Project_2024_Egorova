<?php 
session_start();
include 'db.php';

$userId = $_SESSION['user']['id'];

mysqli_query($db, "UPDATE `cart` SET `status` = 'Новый' WHERE `cart`.`user_id` = '$userId'");

$_SESSION['message'] = 'Заказ создан!';
header('Location: ' . $_SERVER['HTTP_REFERER']);
?>