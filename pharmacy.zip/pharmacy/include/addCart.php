<?php 
session_start();
include 'db.php';

$id = $_GET['id'];
$userId = $_SESSION['user']['id'];

$productQty = mysqli_query($db, "SELECT * FROM `products` WHERE `id` = '$id'");
$product = mysqli_fetch_assoc($productQty);

if($product['count'] > 0) {
    $cartQty = mysqli_query($db, "SELECT * FROM `cart` WHERE `product_id` = '$id' AND `user_id` = '$userId' AND `status` = 'В корзине'");
    $cart = mysqli_fetch_assoc($cartQty);

    if($cart['qty'] > 0) {
        $newProductQty = $product['count'] - 1;
        mysqli_query($db, "UPDATE `products` SET `count` = '$newProductQty' WHERE `products`.`id` = '$id'");
        $newCartQty = $cart['qty'] + 1;
        mysqli_query($db, "UPDATE `cart` SET `qty` = '$newCartQty' WHERE `product_id` = '$id' AND `user_id` = '$userId' AND `status` = 'В корзине'");
        $_SESSION['message'] = 'Кол-во товара обновлено!';
        header('Location: ' . $_SERVER['HTTP_REFERER']);
    } else {
        $newProductQty = $product['count'] - 1;
        mysqli_query($db, "INSERT INTO `cart` (`id`, `user_id`, `product_id`, `qty`, `status`, `timestamp`) 
        VALUES (NULL, '$userId', '$id', '1', 'В корзине', CURRENT_TIMESTAMP)");
        $_SESSION['message'] = 'Товар добавлен!';
        header('Location: ' . $_SERVER['HTTP_REFERER']);
    }
} else {
    $_SESSION['error'] = 'Товара нет в наличии!';
    header('Location: ' . $_SERVER['HTTP_REFERER']);
}
?>