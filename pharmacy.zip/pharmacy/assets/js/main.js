/* mobile menu */
$("#toggler, #overlay").click(() => {
  $("#menu").toggleClass("max-lg:top-0 max-lg:top-full max-lg:-translate-y-full")
  $("#overlay").toggleClass("max-lg:hidden")
})


/* slider */
const swiper = new Swiper('.newProducts', {
    loop: true,
    breakpoints: {
        320: {
          slidesPerView: 1,
          spaceBetween: 20
        },
        640: {
          slidesPerView: 2,
          spaceBetween: 20
        },
        768: {
          slidesPerView: 3,
          spaceBetween: 30
        },
        1024: {
          slidesPerView: 4,
          spaceBetween: 40
        },
        1280: {
          slidesPerView: 5,
          spaceBetween: 50
        }        
    },    
    navigation: {
        nextEl: '.newProductsNext',
        prevEl: '.newProductsPrev',
    }
});