<? if(isset($_SESSION['message'])) { ?>
    <button type="button" class="alert-message fixed top-10 right-10 z-[11] cursor-pointer flex items-center gap-4 px-6 py-2 rounded-2xl w-fit bg-white text-[#00897B] shadow-[0px_0px_13px_-7px_black]">
        <?= $_SESSION['message']; unset($_SESSION['message']); ?>
    </button>
<? } ?>

<? if(isset($_SESSION['error'])) { ?>
    <button type="button" class="alert-message fixed top-10 right-10 z-[11] cursor-pointer flex items-center gap-4 px-6 py-2 rounded-2xl w-fit bg-white text-red-500 shadow-[0px_0px_13px_-7px_black]">
        <?= $_SESSION['error']; unset($_SESSION['error']); ?>
    </button>
<? } ?>

<script>
    $(document).ready(function() {
        // При клике на сообщение, оно будет скрываться
        $('.alert-message').click(function() {
            $(this).fadeOut(500);
        });
    });
</script>