<? 
$title = 'Обновление товара';
include '../layout/header.php'; 

include '../include/db.php';$id = $_GET['id'];

$products = mysqli_query($db, "SELECT * FROM `products` WHERE `id` = '$id'");
$product = mysqli_fetch_assoc($products);
?>

<div class="flex items-center gap-2 font-Nunito tracking-widest text-lg mx-auto w-full">
    <a href="../index.php" class="relative after:absolute after:w-0 after:h-px after:bg-[#282828] after:bottom-0 after:left-0 after:transition-all after:duration-500 hover:after:w-full">
    Главная
    </a>
    <p>/</p>
    <p>Обновление товара</p>
</div>
    
<form action="../include/updateProduct.php" method="POST" enctype="multipart/form-data" class="flex flex-col gap-6 items-center justify-center">
    <input type="hidden" name="id" value="<?= $product['id']; ?>">
    <div class="flex items-center lg:items-start gap-4 max-lg:flex-col md:w-2/3 lg:w-1/2">
        <input type="text" value="<?= $product['title']; ?>" name="title" class="px-4 py-1.5 border border-[#00897B]/70 rounded-xl focus:outline-none w-full lg:w-1/3" placeholder="Наименование" required />
        <input type="file" value="<?= $product['img']; ?>" name="file" class="px-4 py-1.5 border border-[#00897B]/70 rounded-xl focus:outline-none w-full lg:w-1/3" required />
        <input type="text" value="<?= $product['price']; ?>" name="price" class="px-4 py-1.5 border border-[#00897B]/70 rounded-xl focus:outline-none w-full lg:w-1/3" placeholder="Цена" required />
    </div>

    <textarea name="desc" class="w-full md:w-2/3 lg:w-1/2 px-4 py-1.5 border border-[#00897B]/70 rounded-xl focus:outline-none" placeholder="Описание" required><?= $product['desc']; ?></textarea>

    <div class="flex items-center lg:items-start gap-4 max-lg:flex-col md:w-2/3 lg:w-1/2">
        <input type="text" value="<?= $product['maker']; ?>" name="maker" class="px-4 py-1.5 border border-[#00897B]/70 rounded-xl focus:outline-none w-full lg:w-1/3" placeholder="Производитель" required />
        <input type="text" value="<?= $product['country']; ?>" name="country" class="px-4 py-1.5 border border-[#00897B]/70 rounded-xl focus:outline-none w-full lg:w-1/3" placeholder="Страна" required />
        <input type="text" value="<?= $product['count']; ?>" name="count" class="px-4 py-1.5 border border-[#00897B]/70 rounded-xl focus:outline-none w-full lg:w-1/3" placeholder="Кол-во" required />
    </div>

    <button type="submit" class="px-4 py-1.5 bg-[#00897B] text-white rounded-full w-[160px] text-center">
        Обновить
    </button>
</form>

<? include '../layout/footer.php'; ?>
<? include '../layout/message.php'; ?>