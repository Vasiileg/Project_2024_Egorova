<?php 
session_start();
include 'db.php';

$title = mysqli_real_escape_string($db, $_POST['title']);
$price = mysqli_real_escape_string($db, $_POST['price']);
$desc = mysqli_real_escape_string($db, $_POST['desc']);
$maker = mysqli_real_escape_string($db, $_POST['maker']);
$country = mysqli_real_escape_string($db, $_POST['country']);
$count = mysqli_real_escape_string($db, $_POST['count']);

$path = 'assets/images/products/' . time() . $_FILES['file']['name'];
move_uploaded_file($_FILES['file']['tmp_name'], '../' .$path);

mysqli_query($db, "INSERT INTO `products` (`id`, `title`, `img`, `price`, `desc`, `maker`, `country`, `count`) VALUES (NULL, '$title', '$path', '$price', '$desc', '$maker', '$country', '$count')");

$_SESSION['message'] = 'Товар добавлен!';
header('Location: ' . $_SERVER['HTTP_REFERER']);

?>