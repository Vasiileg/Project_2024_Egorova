<? 
$title = 'Главная';
include 'layout/header.php'; 

include 'include/db.php';

$products = mysqli_query($db, "SELECT * FROM `products` WHERE `count` > 0 ORDER BY `id` DESC LIMIT 6");

?>

<div class="flex flex-col gap-6">
    <p class="text-3xl font-Nunito tracking-widest">Новинки</p>
    <div class="swiper w-full relative newProducts">
        <div class="swiper-wrapper">
            <? while($product = mysqli_fetch_assoc($products)) { ?>
                <div class="flex flex-col gap-4 swiper-slide">
                    <a href="Pages/product.php?id=<?= $product['id'];?>" class="flex flex-col gap-2 group">
                        <img src="<?= $product['img']?>" alt="" class="p-2 rounded-xl border transition-all duration-500 group-hover:scale-105 aspect-square object-cover">
                        <span class="line-clamp-2 transition-all duration-500 group-hover:text-[#00897B]"><?= $product['title']?></span>
                    </a>
                    <p class="font-semibold text-2xl mt-auto"><?= number_format($product['price'], 0, '', ' ');?> ₽</p>
                    <div class="flex items-center gap-2">
                        <? if(!isset($_SESSION['user'])) { ?>

                        <? } elseif($_SESSION['user']['role'] == 2) { ?>
                            <a href="pages/updateProduct.php?id=<?= $product['id']; ?>" class="w-full px-4 py-1.5 text-center bg-amber-500 text-white rounded-full border border-abg-amber-500 transition-all duration-500 hover:text-abg-amber-500 hover:bg-white">Изменить</a>
                            <a href="include/deleteProduct.php?id=<?= $product['id']; ?>" class="w-full px-4 py-1.5 text-center bg-red-500 text-white rounded-full border border-red-500 transition-all duration-500 hover:text-red-500 hover:bg-white">Удалить</a>
                        <? } else { ?>
                            <a href="include/addCart.php?id=<?= $product['id']; ?>" class="w-full px-4 py-1.5 text-center bg-[#00897B] text-white rounded-full border border-[#00897B] transition-all duration-500 hover:text-[#00897B] hover:bg-white">В корзину</a>
                        <? } ?>
                    </div>
                </div>
            <?}?>
        </div>
        <button class="newProductsPrev absolute top-1/2 -translate-y-1/2 z-[3] left-2 w-10 h-10 rounded-full bg-gray-200 border flex items-center justify-center">
            <img src="assets/images/slider/next.svg" alt="" class="scale-[-1]">
        </button>
        <button class="newProductsNext absolute top-1/2 -translate-y-1/2 z-[3] right-2 w-10 h-10 rounded-full bg-gray-200 border flex items-center justify-center">
            <img src="assets/images/slider/next.svg" alt="">
        </button>
    </div>
</div>
<div class="flex flex-col gap-6">
    <p class="text-3xl font-Nunito tracking-widest">Показатели</p>
    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <!-- Пункты выдачи -->
        <div class="flex flex-col gap-2 items-center text-center">
            <div class="relative w-40 h-40">
                <svg class="transform -rotate-90" viewBox="0 0 36 36">
                    <circle class="text-gray-300" stroke-width="3" stroke="currentColor" fill="transparent" r="16" cx="18"
                        cy="18" />
                    <circle class="text-[#00897B]" stroke-width="3" stroke-dasharray="100" stroke-dashoffset="28"
                        stroke-linecap="round" stroke="currentColor" fill="transparent" r="16" cx="18" cy="18" />
                </svg>
                <div class="absolute inset-0 flex items-center justify-center font-semibold">
                    72/100
                </div>
            </div>
            <p class="text-center font-medium text-gray-600 font-Nunito">Пункты выдачи</p>
        </div>
        
        <!-- Скорость обработки заказов -->
        <div class="flex flex-col gap-2 items-center text-center">
            <div class="relative w-40 h-40">
                <svg class="transform -rotate-90" viewBox="0 0 36 36">
                    <circle class="text-gray-300" stroke-width="3" stroke="currentColor" fill="transparent" r="16" cx="18"
                        cy="18" />
                    <circle class="text-[#00897B]" stroke-width="3" stroke-dasharray="100" stroke-dashoffset="10"
                        stroke-linecap="round" stroke="currentColor" fill="transparent" r="16" cx="18" cy="18" />
                </svg>
                <div class="absolute inset-0 flex items-center justify-center font-semibold">
                    90%
                </div>
            </div>
            <p class="text-center font-medium text-gray-600 font-Nunito">Обработка заказов</p>
        </div>
        
        <!-- Наличие популярных препаратов -->
        <div class="flex flex-col gap-2 items-center text-center">
            <div class="relative w-40 h-40">
                <svg class="transform -rotate-90" viewBox="0 0 36 36">
                    <circle class="text-gray-300" stroke-width="3" stroke="currentColor" fill="transparent" r="16" cx="18"
                        cy="18" />
                    <circle class="text-[#00897B]" stroke-width="3" stroke-dasharray="100" stroke-dashoffset="15"
                        stroke-linecap="round" stroke="currentColor" fill="transparent" r="16" cx="18" cy="18" />
                </svg>
                <div class="absolute inset-0 flex items-center justify-center font-semibold">
                    85%
                </div>
            </div>
            <p class="text-center font-medium text-gray-600 font-Nunito">Популярные препараты</p>
        </div>
        
        <!-- Доверие пользователей -->
        <div class="flex flex-col gap-2 items-center text-center">
            <div class="relative w-40 h-40">
                <svg class="transform -rotate-90" viewBox="0 0 36 36">
                    <circle class="text-gray-300" stroke-width="3" stroke="currentColor" fill="transparent" r="16" cx="18"
                        cy="18" />
                    <circle class="text-[#00897B]" stroke-width="3" stroke-dasharray="100" stroke-dashoffset="6"
                        stroke-linecap="round" stroke="currentColor" fill="transparent" r="16" cx="18" cy="18" />
                </svg>
                <div class="absolute inset-0 flex items-center justify-center font-semibold">
                    94%
                </div>
            </div>
            <p class="text-center font-medium text-gray-600 font-Nunito">Доверие пользователей</p>
        </div>
    </div>
</div>
<div class="flex flex-col gap-6">
    <p class="text-3xl font-Nunito tracking-widest">Акции</p>
    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <div class="w-full rounded-xl border border-[#00897B]/10 shadow-[0px_0px_13px_-7px_black] overflow-hidden">
            <img src="assets/images/stocks/1.png" alt="" class="w-full aspect-video object-cover">
        </div>
        <div class="w-full rounded-xl border border-[#00897B]/10 shadow-[0px_0px_13px_-7px_black] overflow-hidden">
            <img src="assets/images/stocks/2.png" alt="" class="w-full aspect-video object-cover">
        </div>
        <div class="w-full rounded-xl border border-[#00897B]/10 shadow-[0px_0px_13px_-7px_black] overflow-hidden">
            <img src="assets/images/stocks/3.png" alt="" class="w-full aspect-video object-cover">
        </div>
        <div class="w-full rounded-xl border border-[#00897B]/10 shadow-[0px_0px_13px_-7px_black] overflow-hidden">
            <img src="assets/images/stocks/4.png" alt="" class="w-full aspect-video object-cover">
        </div>
    </div>
</div>
<div class="flex flex-col gap-6">
    <p class="text-3xl font-Nunito tracking-widest">Фармия</p>
    <p class="text-gray-600 tracking-wider">Фармия – современная онлайн-аптека с широким выбором лекарств, витаминов и товаров для красоты и здоровья. Мы заботимся о вашем самочувствии, предлагая доступные цены, удобные способы заказа и быструю доставку до двери.</p>
    <img src="assets/images/about/main.jpg" alt="" class="rounded-xl w- lg:w-1/2 mx-auto aspect-video object-cover">
    <a href="Pages/about.php" class="self-end w-fit rounded-full px-4 py-1.5 bg-[#00897B] text-white border border-[#00897B] transition-all duration-500 hover:text-[#00897B] hover:bg-white">Подробнее</a>
</div>

<? include 'layout/footer.php'; ?>
<? include 'layout/message.php'; ?>