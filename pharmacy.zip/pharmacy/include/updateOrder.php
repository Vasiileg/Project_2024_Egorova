<?php 
session_start();
include 'db.php';

$id = mysqli_real_escape_string($db, $_POST['id']);
$status = mysqli_real_escape_string($db, $_POST['status']);

mysqli_query($db, "UPDATE `cart` SET `status` = '$status' WHERE `cart`.`id` = '$id'");

$_SESSION['message'] = 'Статус обновлён!';
header('Location: ' . $_SERVER['HTTP_REFERER']);
?>