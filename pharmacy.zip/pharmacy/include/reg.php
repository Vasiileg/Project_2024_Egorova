<?php 
session_start();
include 'db.php';

$name = mysqli_real_escape_string($db, $_POST['name']);
$surname = mysqli_real_escape_string($db, $_POST['surname']);
$patronymic = mysqli_real_escape_string($db, $_POST['patronymic']);
$login = mysqli_real_escape_string($db, $_POST['login']);
$psw = mysqli_real_escape_string($db, $_POST['password']);
$number = mysqli_real_escape_string($db, $_POST['number']);
$date = mysqli_real_escape_string($db, $_POST['date']);

$checkLogin = mysqli_query($db, "SELECT * FROM `users` WHERE `login` = '$login'");

if(mysqli_num_rows($checkLogin) > 0) {
    $_SESSION['error'] = 'Пользователь с таким логином уже существует!';
    header('Location: ' . $_SERVER['HTTP_REFERER']);
} else { 
    $pswHash = password_hash($psw, PASSWORD_DEFAULT);
    mysqli_query($db, "INSERT INTO `users` (`id`, `name`, `surname`, `patronymic`, `login`, `password`, `number`, `date`, `role`) 
    VALUES (NULL, '$name', '$surname', '$patronymic', '$login', '$pswHash', '$number', '$date', '1')");
    $_SESSION['message'] = 'Пользователь зарегистрирован!';
    header('Location: ../pages/auth.php');
}
?>