<?php
$title = 'Профиль';
include '../layout/header.php';

include '../include/db.php';
$userId = $_SESSION['user']['id'];

$orders = mysqli_query($db, "SELECT *, `cart`.id as cid FROM `cart` JOIN `products` WHERE `cart`.product_id = `products`.id AND `cart`.user_id = '$userId' AND `status` != 'В корзине'");
?>

<div class="flex items-center gap-2 font-Nunito tracking-widest text-lg mx-auto w-full">
    <a href="../index.php" class="relative after:absolute after:w-0 after:h-px after:bg-[#282828] after:bottom-0 after:left-0 after:transition-all after:duration-500 hover:after:w-full">
    Главная
    </a>
    <p>/</p>
    <p>Профиль</p>
</div>

<div class="flex flex-col gap-6">
    <p class="text-2xl font-Nunito tracking-widest">Заказы</p>
    <?php while ($order = mysqli_fetch_assoc($orders)) { ?>
        <div class="flex flex-col gap-4 rounded-xl p-4 border border-[#00897B]">
            <p><span class="text-[#00897B] font-medium">Количество товаров:</span> <?= $order['qty']; ?></p>
            <p><span class="text-[#00897B] font-medium">Наименование:</span> <?= $order['title']; ?></p>
            <p><span class="text-[#00897B] font-medium">Статус:</span> <?= $order['status']; ?></p>
            <p><span class="text-[#00897B] font-medium">Время заказа:</span> <?= $order['timestamp']; ?></p>
            <a href="../include/deleteOrder.php?id=<?= $order['cid']; ?>" class="bg-red-500 py-2 px-4 text-white rounded-lg w-fit">Удалить</a>
        </div>
    <?php } ?>
</div>

<div class="flex flex-col gap-6">
    <p class="text-2xl font-Nunito tracking-widest">Выход из аккаунта</p>
    <a href="../include/logout.php" class="w-fit px-4 py-1.5 text-center bg-[#00897B] text-white rounded-full border border-[#00897B] transition-all duration-500 hover:text-[#00897B] hover:bg-white">Выход</a>
</div>

<?php include '../layout/message.php'; ?>
<?php include '../layout/footer.php'; ?>