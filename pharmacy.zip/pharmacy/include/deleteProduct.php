<?php 
session_start();
include 'db.php';

$id = $_GET['id'];

mysqli_query($db, "DELETE FROM `products` WHERE `products`.`id` = '$id'");

$_SESSION['message'] = 'Товар удален!';
header('Location: ' . $_SERVER['HTTP_REFERER']);
?>