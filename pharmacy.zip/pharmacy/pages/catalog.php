<? 
$title = 'Каталог';
include '../layout/header.php'; 
include '../include/db.php';

// Инициализация переменных
$price = isset($_GET['price']) ? $_GET['price'] : ''; 
$search = isset($_GET['search']) ? mysqli_real_escape_string($db, $_GET['search']) : '';

// Формируем SQL-запрос
$query = "SELECT * FROM `products` WHERE `count` > 0";

// Условие для поиска
if ($search) {
    $query .= " AND `title` LIKE '%$search%'";
}

// Условие для сортировки
if ($price) {
    $query .= " ORDER BY `price` $price";
}

// Выполняем запрос
$products = mysqli_query($db, $query);
?>

<div class="flex items-center gap-2 font-Nunito tracking-widest text-lg mx-auto w-full">
    <a href="../index.php" class="relative after:absolute after:w-0 after:h-px after:bg-[#282828] after:bottom-0 after:left-0 after:transition-all after:duration-500 hover:after:w-full">
    Главная
    </a>
    <p>/</p>
    <p>Каталог</p>
</div>            

<div class="flex max-lg:flex-col w-full gap-8">
    <div class="flex flex-col gap-6 w-full lg:w-1/5">
        <form action="catalog.php" method="GET" class="flex flex-col gap-2">
            <p class="text-2xl font-Nunito tracking-widest text-[#00897B]">Сортировка</p>
            <select name="price" class="rounded-full px-4 py-1.5 border border-[#00897B]/70">
                <option value="ASC" <? if(isset($_GET['price']) && $_GET['price'] == 'ASC') { echo 'selected'; } ?>>По возрастанию цены</option>
                <option value="DESC" <? if(isset($_GET['price']) && $_GET['price'] == 'DESC') { echo 'selected'; } ?>>По убыванию цены</option>
            </select>
            <input type="hidden" name="search" value="<?= htmlspecialchars($_GET['search'] ?? '') ?>" />
            <button type="submit" class="w-full px-4 py-1.5 text-center bg-[#00897B] text-white rounded-full border border-[#00897B] transition-all duration-500 hover:text-[#00897B] hover:bg-white">Применить</button>
        </form>
    </div>
    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 w-full lg:w-4/5">
        <? while($product = mysqli_fetch_assoc($products)) { ?>
            <div class="flex flex-col gap-4">
                <a href="product.php?id=<?= $product['id'];?>" class="flex flex-col gap-2 group">
                    <img src="../<?= $product['img']?>" alt="" class="p-2 rounded-xl border transition-all duration-500 group-hover:scale-105 aspect-square object-cover">
                    <span class="line-clamp-2 transition-all duration-500 group-hover:text-[#00897B]"><?= $product['title']?></span>
                </a>
                <p class="font-semibold text-2xl mt-auto"><?= number_format($product['price'], 0, '', ' ');?> ₽</p>
                <div class="flex items-center gap-2">
                    <? if(!isset($_SESSION['user'])) { ?>

                    <? } elseif($_SESSION['user']['role'] == 2) { ?>
                        <a href="updateProduct.php?id=<?= $product['id']; ?>" class="w-full px-4 py-1.5 text-center bg-amber-500 text-white rounded-full border border-abg-amber-500 transition-all duration-500 hover:text-abg-amber-500 hover:bg-white">Изменить</a>
                        <a href="../include/deleteProduct.php?id=<?= $product['id']; ?>" class="w-full px-4 py-1.5 text-center bg-red-500 text-white rounded-full border border-red-500 transition-all duration-500 hover:text-red-500 hover:bg-white">Удалить</a>
                    <? } else { ?>
                        <a href="../include/addCart.php?id=<?= $product['id']; ?>" class="w-full px-4 py-1.5 text-center bg-[#00897B] text-white rounded-full border border-[#00897B] transition-all duration-500 hover:text-[#00897B] hover:bg-white">В корзину</a>
                    <? } ?>
                </div>
            </div>
        <?}?>
    </div>
</div>

<? include '../layout/footer.php'; ?>
<? include '../layout/message.php'; ?>