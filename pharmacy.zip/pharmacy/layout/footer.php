</main>

<footer class="w-full text-center bg-[#00897B]/10 py-2 font-Nunito mt-auto">Copyright 2024 - Фармия</footer>

<script src="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.js"></script>
<script src="https://code.jquery.com/jquery-3.7.1.min.js" integrity="sha256-/JqT3SQfawRcv/BIHPThkBvs0OEvtFFmqPF/lYI/Cxo=" crossorigin="anonymous"></script>
<script src="/pharmacy/assets/js/main.js"></script>
</body>
</html>