<? 
$title = 'Админ панель';
include '../layout/header.php'; 

include '../include/db.php';
$orders = mysqli_query($db, "SELECT *, `cart`.id as cart_id FROM `cart` JOIN `users` WHERE `cart`.user_id = `users`.id AND `status` != 'В корзине'");
?>

<div class="flex items-center gap-2 font-Nunito tracking-widest text-lg mx-auto w-full">
    <a href="../index.php" class="relative after:absolute after:w-0 after:h-px after:bg-[#282828] after:bottom-0 after:left-0 after:transition-all after:duration-500 hover:after:w-full">
    Главная
    </a>
    <p>/</p>
    <p>Админ панель</p>
</div>        

<form action="../include/addProduct.php" method="POST" enctype="multipart/form-data" class="flex flex-col gap-6 items-center justify-center">
    <p class="text-2xl font-Nunito tracking-widest w-full">Добавление товара</p>
    <div class="flex items-center lg:items-start gap-4 max-lg:flex-col md:w-2/3 lg:w-1/2">
        <input type="text" name="title" class="px-4 py-1.5 border border-[#00897B]/70 rounded-xl focus:outline-none w-full lg:w-1/3" placeholder="Наименование" required />
        <input type="file" name="file" class="px-4 py-1.5 border border-[#00897B]/70 rounded-xl focus:outline-none w-full lg:w-1/3" required />
        <input type="text" name="price" class="px-4 py-1.5 border border-[#00897B]/70 rounded-xl focus:outline-none w-full lg:w-1/3" placeholder="Цена" required />
    </div>

    <textarea name="desc" class="w-full md:w-2/3 lg:w-1/2 px-4 py-1.5 border border-[#00897B]/70 rounded-xl focus:outline-none" placeholder="Описание" required></textarea>

    <div class="flex items-center lg:items-start gap-4 max-lg:flex-col md:w-2/3 lg:w-1/2">
        <input type="text" name="maker" class="px-4 py-1.5 border border-[#00897B]/70 rounded-xl focus:outline-none w-full lg:w-1/3" placeholder="Производитель" required />
        <input type="text" name="country" class="px-4 py-1.5 border border-[#00897B]/70 rounded-xl focus:outline-none w-full lg:w-1/3" placeholder="Страна" required />
        <input type="text" name="count" class="px-4 py-1.5 border border-[#00897B]/70 rounded-xl focus:outline-none w-full lg:w-1/3" placeholder="Кол-во" required />
    </div>

    <button type="submit" class="px-4 py-1.5 bg-[#00897B] text-white rounded-full w-[160px] text-center">
        Добавить
    </button>
</form>

<div class="flex flex-col gap-6">
    <p class="text-2xl font-Nunito tracking-widest">Заказы</p>
    <?php while ($order = mysqli_fetch_assoc($orders)) { ?>
        <div class="flex flex-col gap-4 rounded-xl p-4 border border-[#00897B]">
            <a href="../include/deleteOrder.php?id=<?= $order['cart_id']; ?>" class="bg-red-500 py-2 px-4 text-white rounded-lg w-fit self-end">Удалить</a>
            <p><span class="text-[#00897B] font-medium">Количество товаров:</span> <?= $order['qty']; ?></p>
            <p><span class="text-[#00897B] font-medium">Покупатель:</span> <?= $order['name']; ?></p>
            <p><span class="text-[#00897B] font-medium">Статус:</span> <?= $order['status']; ?></p>
            <p><span class="text-[#00897B] font-medium">Время заказа:</span> <?= $order['timestamp']; ?></p>
            <form action="../include/updateOrder.php" method="POST" class="flex flex-col gap-2">
                <p>Смена статуса</p>
                <input type="text" name="id" value="<?= $order['cart_id']; ?>" class="hidden">
                <select name="status" class="px-4 py-1.5 rounded-xl border border-[#00897B]/70 w-fit">
                    <option value="Новый">Новый</option>
                    <option value="Подтверждён">Подтверждён</option>
                    <option value="Отменён">Отменён</option>
                </select>
                <button type="submit" class="px-4 py-1.5 bg-[#00897B] text-white rounded-full w-[160px] text-center">
                    Применить
                </button>
            </form>
        </div>
    <?php } ?>
</div>

<div class="flex flex-col gap-6">
    <p class="text-2xl font-Nunito tracking-widest">Выход из аккаунта</p>
    <a href="../include/logout.php" class="w-fit px-4 py-1.5 text-center bg-[#00897B] text-white rounded-full border border-[#00897B] transition-all duration-500 hover:text-[#00897B] hover:bg-white">Выход</a>
</div>


<? include '../layout/footer.php'; ?>
<? include '../layout/message.php'; ?>