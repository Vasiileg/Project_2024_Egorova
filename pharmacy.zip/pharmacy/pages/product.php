<? 
$title = 'Страница товара';
include '../layout/header.php'; 
include '../include/db.php'; 

$id = $_GET['id'];
$products = mysqli_query($db, "SELECT * FROM `products` WHERE `id` = '$id'");
$product = mysqli_fetch_assoc($products);
?>

<div class="flex items-center gap-2 font-Nunito tracking-widest text-lg mx-auto w-full">
    <a href="../index.php" class="relative after:absolute after:w-0 after:h-px after:bg-[#282828] after:bottom-0 after:left-0 after:transition-all after:duration-500 hover:after:w-full">
        Главная
    </a>
    <p>/</p>
    <a href="catalog.php" class="relative after:absolute after:w-0 after:h-px after:bg-[#282828] after:bottom-0 after:left-0 after:transition-all after:duration-500 hover:after:w-full">
        Каталог
    </a>
    <p>/</p>
    <p>Страница товара</p>
</div>   

<p class="text-2xl font-Nunito tracking-widest"><?= $product['title']; ?></p>
<div class="flex max-lg:flex-col gap-8">
    <img src="../<?= $product['img']?>" alt="" class="p-2 rounded-xl border w-full lg:w-2/5 shadow-[0px_0px_13px_-7px_black] transition-all duration-500 hover:scale-105">
    <div class="flex flex-col gap-6 w-full lg:w-2/5 p-4 border border-[#00897B]/70 rounded-xl h-fit">
        <div class="flex items-start w-full gap-6 font-medium">
            <p class="opacity-70">Бренд</p>
            <div class="min-w-[30%] mt-3.5 grow border-b border-dashed border-[#00897B]/70"></div>
            <p><?= $product['maker']; ?></p>
        </div>
        <div class="flex items-start w-full gap-6 font-medium">
            <p class="opacity-70">Страна</p>
            <div class="min-w-[30%] mt-3.5 grow border-b border-dashed border-[#00897B]/70"></div>
            <p><?= $product['country']; ?></p>
        </div>
        <p class="text-3xl font-semibold text-[#00897B]/70"><?= number_format($product['price'], 0, '', ' ');?> ₽</p>
        <p class="text-base text-gray-400">* Осталось <?= $product['count']; ?> шт.</p>
        <div class="flex items-center gap-2">
            <? if(!isset($_SESSION['user'])) { ?>

            <? } elseif($_SESSION['user']['role'] == 2) { ?>
                <a href="updateProduct.php?id=<?= $product['id']; ?>" class="w-full px-4 py-1.5 text-center bg-amber-500 text-white rounded-full border border-abg-amber-500 transition-all duration-500 hover:text-abg-amber-500 hover:bg-white">Изменить</a>
                <a href="../include/deleteProduct.php?id=<?= $product['id']; ?>" class="w-full px-4 py-1.5 text-center bg-red-500 text-white rounded-full border border-red-500 transition-all duration-500 hover:text-red-500 hover:bg-white">Удалить</a>
            <? } else { ?>
                <a href="../include/addCart.php?id=<?= $product['id']; ?>" class="w-full px-4 py-1.5 text-center bg-[#00897B] text-white rounded-full border border-[#00897B] transition-all duration-500 hover:text-[#00897B] hover:bg-white">В корзину</a>
            <? } ?>
        </div>
    </div>
</div>
<p class="font-Nunito tracking-widest"><?= $product['desc']; ?></p>
        

<? include '../layout/footer.php'; ?>
<? include '../layout/message.php'; ?>