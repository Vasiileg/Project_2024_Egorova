<? 
$title = 'Корзина';
include '../layout/header.php'; 

include '../include/db.php';
if(isset($_SESSION['user'])) {
    $userId = $_SESSION['user']['id'];
    $carts = mysqli_query($db, "SELECT * FROM `cart` JOIN `products` WHERE `cart`.product_id = `products`.id AND `user_id` = '$userId' AND `status` = 'В корзине' AND `qty` > 0");
}

?>

<div class="flex items-center gap-2 font-Nunito tracking-widest text-lg mx-auto w-full">
    <a href="../index.php" class="relative after:absolute after:w-0 after:h-px after:bg-[#282828] after:bottom-0 after:left-0 after:transition-all after:duration-500 hover:after:w-full">
    Главная
    </a>
    <p>/</p>
    <p>Корзина</p>
</div>
    
<?if(!isset($_SESSION['user']['id'])) { ?>
    <div class="flex flex-col gap-6 items-center text-center w-full">
        <p class="text-3xl font-Nunito tracking-widest text-[#00897B]/70">Необходимо войти в аккант для заказа</p>
        <a href="auth.php" class="px-4 py-1.5 bg-[#00897B] text-white rounded-full font-Nunito w-fit">Вход</a>
    </div>
<?} else {?>
    
<? if (mysqli_num_rows($carts)) {?>
<div class="flex flex-col gap-6 w-full">
    <p class="text-3xl font-Nunito tracking-widest text-[#00897B]/70">Список товаров</p>
    
    <!-- Карточки товаров -->
    <? while ($cart = mysqli_fetch_assoc($carts)) { ?>
        <div class="flex flex-col gap-4">
            <div class="flex lg:items-center gap-6 max-lg:flex-col w-full">
                <img src="../<?= $cart['img']; ?>" alt="" class="p-2 rounded-xl border transition-all duration-500 group-hover:scale-105 aspect-square object-cover w-full lg:w-1/3">
                <div class="flex flex-col gap-4 w-full lg:w-1/3">
                    <p class="text-2xl font-Comfortaa"><?= $cart['title']; ?></p>
                    <p class="text-xl font-semibold">2,500 ₽</p>      
                    <div class="flex items-center gap-4">
                        <a href="../include/minusProduct.php?id=<?= $cart['id']; ?>" class="w-8 h-8 p-1 border border-[#00897B] rounded-xl">
                            <img src="../assets/images/cart/minus.svg" alt="">
                        </a>
                        <p class="text-xl font-semibold">кол-во: <?= $cart['qty']; ?></p>
                        <a href="../include/plusProduct.php?id=<?= $cart['id']; ?>" class="w-8 h-8 p-1 border border-[#00897B] rounded-xl">
                            <img src="../assets/images/cart/plus.svg" alt="">
                        </a>
                    </div>
                </div>
            </div>                  
        </div>
    <?}?>
</div>
    
<div class="flex flex-col gap-6">
    <p class="text-3xl font-Nunito tracking-widest text-[#00897B]/70">Оформление заказа</p>        
    <form action="../include/order.php" method="POST" class="flex flex-col gap-4 w-full items-center md:w-2/3 lg:w-1/2 md:mx-auto">
        <div class="flex items-start gap-2 w-full">
            <input type="text" name="card-number" class="px-4 py-1.5 border border-[#00897B]/70 rounded-xl focus:outline-none w-full md:w-2/4" placeholder="Номер карты" required />
            <input type="text" name="expiry-date" class="px-4 py-1.5 border border-[#00897B]/70 rounded-xl focus:outline-none w-full md:w-1/4" placeholder="YY/YY" required />
            <input type="text" name="cvc" class="px-4 py-1.5 border border-[#00897B]/70 rounded-xl focus:outline-none w-full md:w-1/4" placeholder="CVC" required />
        </div>
    
        <textarea name="address" class="px-4 py-1.5 border border-[#00897B]/70 rounded-xl focus:outline-none w-full" placeholder="Адрес доставки" required></textarea>
    
        <button type="submit" class="px-4 py-1.5 bg-[#00897B] text-white rounded-full font-Nunito w-fit">
            Оформить заказ
        </button>
    </form>
</div>           

<?} else {?>
    <div class="flex flex-col gap-6 items-center text-center w-full">
        <p class="text-3xl font-Nunito tracking-widest text-[#00897B]/70">В корзине нет товаров</p>
        <a href="catalog.php" class="px-4 py-1.5 bg-[#00897B] text-white rounded-full font-Nunito w-fit">За покупками</a>
    </div>
<?}}?>

<? include '../layout/footer.php'; ?>
<? include '../layout/message.php'; ?>