<?php 
session_start();
include 'db.php';

$id = $_POST['id'];
$title = mysqli_real_escape_string($db, $_POST['title']);
$price = mysqli_real_escape_string($db, $_POST['price']);
$desc = mysqli_real_escape_string($db, $_POST['desc']);
$maker = mysqli_real_escape_string($db, $_POST['maker']);
$country = mysqli_real_escape_string($db, $_POST['country']);
$count = mysqli_real_escape_string($db, $_POST['count']);

$path = 'assets/images/products/' . time() . $_FILES['file']['name'];
move_uploaded_file($_FILES['file']['tmp_name'], '../' .$path);

mysqli_query($db, "UPDATE `products` SET `title` = '$title', `img` = '$path', `price` = '$price',
 `desc` = '$desc', `maker` = '$maker', `country` = '$country', `count` = '$count' WHERE `products`.`id` = '$id'");
$_SESSION['message'] = 'Товар обновлен!';
header('Location: ../pages/catalog.php');

?>