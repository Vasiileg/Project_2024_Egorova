<? 
$title = 'О компании';
include '../layout/header.php'; 

?>

<div class="flex items-center gap-2 font-Nunito tracking-widest text-lg mx-auto w-full">
    <a href="../index.php" class="relative after:absolute after:w-0 after:h-px after:bg-[#665E5E] after:bottom-0 after:left-0 after:transition-all after:duration-500 hover:after:w-full">Главная</a>
    <p>/</p>
    <p>О компании</p>
</div>
<div class="flex flex-col gap-6">
    <p class="text-gray-600 tracking-wider">Фармия – современная онлайн-аптека с широким выбором лекарств, витаминов и товаров для красоты и здоровья. Мы заботимся о вашем самочувствии, предлагая доступные цены, удобные способы заказа и быструю доставку до двери.</p>
    <img src="../Assets/Images/about/main.jpg" alt="" class="rounded-xl w- lg:w-1/2 mx-auto aspect-video object-cover">
</div>
<div class="flex flex-col gap-6">
    <div class="flex flex-col gap-2">
        <p><span class="font-Nunito tracking-widest text-[#00897B]/70">Часы работы:</span> пн—сб с 10:00 — 20:00</p>
        <div class="flex items-center gap-2">
            <p class="font-Nunito tracking-widest text-[#00897B]/70">Мы в соцсетях:</p>
            <a href="https://t.me/Vasileq" target="_blank">
                <img src="../Assets/Images/about/tg.svg" alt="" class="w-8">
            </a>
            <a href="" target="_blank">
                <img src="../Assets/Images/about/whatsapp.svg" alt="" class="w-8">                    
            </a>
        </div>
        <p><span class="font-Nunito tracking-widest text-[#00897B]/70">Адрес:</span> Москва, ул Пушкина, д. 1</p>
    </div>
    <iframe class="w-full h-[400px] rounded-xl shadow-[0px_0px_13px_-7px_black]" src="https://yandex.ru/map-widget/v1/?um=constructor%3Aca9938ebdc9acd66703b7f498d6b34e78c9910b76fcde25026bdbe728a855ad7&amp;source=constructor" frameborder="0"></iframe>
</div>
<div class="flex flex-col gap-6 items-center text-center">
    <p class="font-Nunito tracking-widest text-[#00897B]/70 text-4xl">Доставка</p>
    <p class="md:w-2/3 lg:w-1/2 text-xl">
        На данный момент доступен только самовывоз.
    </p>
</div>           

<? include '../layout/footer.php'; ?>
<? include '../layout/message.php'; ?>